import './assets/main.css'

import { createApp } from 'vue'; // 移除多余的 ref、watch（main.js 中用不到）
import App from './App.vue'
// 1. 导入路由实例
import router from './router';

const app = createApp(App)

// 2. 注册路由（关键步骤，让整个项目支持路由功能）
app.use(router);

app.mount('#app')