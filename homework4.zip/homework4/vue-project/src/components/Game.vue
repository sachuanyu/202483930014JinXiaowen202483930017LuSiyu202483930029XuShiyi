<template>
  <div class="game-container">
    <h2 class="window-title">Magic Tower</h2>
    <div class="message-box">{{ gameMessage }}</div>

    <!-- 地图渲染 -->
    <div class="map-container">
      <div
          v-for="(row, rowIdx) in gameData.map[gameData.currentLevel]"
          :key="rowIdx"
          class="map-row"
      >
        <div
            v-for="(tile, colIdx) in row"
            :key="colIdx"
            class="map-tile"
            :style="{ width: '100px', height: '100px' }"
        >
          <img
              :src="chooseImage(tile)"
              :alt="getTileAlt(tile)"
              class="tile-img"
              :style="{ width: '100%', height: '100%', objectFit: 'cover' }"
          >
        </div>
      </div>
    </div>

    <!-- 英雄状态 -->
    <div class="status-bar">
      生命值：{{ gameData.heroHealth }} |
      钥匙数：{{ gameData.keyNum }} |
      当前楼层：{{ gameData.currentLevel + 1 }} |
      操作：W(上) S(下) A(左) D(右) V/B(特殊功能) 0(菜单)
    </div>

    <!-- 游戏结束弹窗 -->
    <div v-if="isGameOver" class="game-over-modal">
      <h3>{{ isWin ? '恭喜胜利！' : '游戏失败！' }}</h3>
      <p>{{ gameMessage }}</p>
      <button @click="restartGame">重新开始</button>
    </div>

    <!-- 引入菜单组件 -->
    <Menu ref="menuRef" />
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { gameData, readMapFromFile, printMap } from '@/utils/gameData.js';
import { handleInput, handleSpecialKey } from '@/utils/gameControl.js';
import Menu from '@/components/Menu.vue';

// 核心修复：用 Vue 支持的 import 导入图片（替代 Node.js 的 require）
import WallImg from '@/assets/Wall.jpg';
import FloorImg from '@/assets/Floor.jpg';
import KeyImg from '@/assets/Key.jpg';
import DoorImg from '@/assets/Door.jpg';
import StairImg from '@/assets/Stair.jpg';
import ExitImg from '@/assets/Exit.jpg';
import HeroImg from '@/assets/Hero.jpg';
import PotionImg from '@/assets/Potion.jpg';
import MonsterImg from '@/assets/Monster.jpg';

// 菜单组件引用
const menuRef = ref(null);
// 游戏状态变量
const gameMessage = ref('游戏开始！使用 W/S/A/D 移动，按 0 打开菜单');
const isGameOver = ref(false);
const isWin = ref(false);

// 页面加载时初始化
onMounted(() => {
  readMapFromFile(); // 加载地图（从 menuConfig.json 读取）
  window.addEventListener('keydown', handleKeyDown);
});

// 页面卸载时移除监听
onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyDown);
});

// 监听游戏数据变化，自动刷新界面
watch(
    () => [gameData.pX, gameData.pY, gameData.currentLevel, gameData.map],
    () => {
      console.log("界面已刷新");
    },
    { deep: true }
);

/**
 * 处理键盘事件
 */
const handleKeyDown = (e) => {
  if (isGameOver.value) return;

  const key = e.key.toLowerCase();
  // 移动按键（a/s/d/w）
  if (['a', 's', 'd', 'w'].includes(key)) {
    const result = handleInput(key);
    gameMessage.value = result.message;
    isGameOver.value = result.isGameOver;
    isWin.value = result.isWin;
  }
  // 特殊功能按键（v/b）
  else if (['v', 'b'].includes(key)) {
    handleSpecialKey(key).then(msg => {
      gameMessage.value = msg;
    });
  }
  // 打开菜单（0 键，对应 Java 的 menu.enterMenu()）
  else if (key === '0') {
    menuRef.value.openMenu();
  }
};

/**
 * 重新开始游戏
 */
const restartGame = () => {
  readMapFromFile();
  gameMessage.value = '游戏重启！使用 W/S/A/D 移动，按 0 打开菜单';
  isGameOver.value = false;
  isWin.value = false;
};

/**
 * 选择地图元素图片（复现 Java GUI.chooseImage()，修复 require 错误）
 */
const chooseImage = (index) => {
  // 映射图片变量（替代原有的文件名）
  const imageMap = {
    0: WallImg,
    1: FloorImg,
    2: KeyImg,
    3: DoorImg,
    4: StairImg,
    5: ExitImg,
    6: HeroImg,
    7: PotionImg,
    8: MonsterImg
  };

  if (index > 10) {
    return PotionImg;
  } else if (index < 0) {
    return MonsterImg;
  } else {
    return imageMap[index] || FloorImg;
  }
};

/**
 * 图片 alt 说明
 */
const getTileAlt = (tileValue) => {
  const altMap = {
    0: '墙', 1: '地板', 2: '钥匙', 3: '门',
    4: '楼梯', 5: '出口', 6: '英雄',
    7: '药水', 8: '怪物',
    '>10': '药水', '<0': '怪物'
  };
  if (tileValue > 10) return altMap['>10'];
  if (tileValue < 0) return altMap['<0'];
  return altMap[tileValue] || '地板';
};
</script>

<style scoped>
.game-container {
  width: fit-content;
  margin: 20px auto;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-shadow: 0 0 5px rgba(0,0,0,0.1);
}

.window-title {
  text-align: center;
  margin: 0 0 10px 0;
  font-size: 18px;
  color: #333;
}

.message-box {
  margin: 0 0 10px 0;
  padding: 8px;
  background: #f5f5f5;
  border-radius: 4px;
  text-align: center;
  font-size: 14px;
}

.map-row {
  display: flex;
  margin: 0;
  padding: 0;
}

.map-tile {
  margin: 0;
  padding: 0;
  border: none;
  overflow: hidden;
}

.tile-img {
  image-rendering: smooth;
}

.status-bar {
  margin: 10px 0 0 0;
  padding: 8px;
  background: #f5f5f5;
  border-radius: 4px;
  text-align: center;
  font-size: 14px;
  color: #333;
}

.game-over-modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: white;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 0 20px rgba(0,0,0,0.3);
  text-align: center;
}

.game-over-modal button {
  padding: 8px 16px;
  margin-top: 10px;
  cursor: pointer;
  background: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
}
</style>