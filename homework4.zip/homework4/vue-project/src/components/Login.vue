<template>
  <div class="login-container">
    <h2 class="login-title">登录</h2>

    <div class="form-group">
      <label class="form-label">Username</label>
      <input
          type="text"
          class="form-input"
          v-model="username"
          placeholder="请输入用户名"
          @keyup.enter="handleLogin"
      />
    </div>

    <div class="form-group">
      <label class="form-label">Password</label>
      <input
          type="password"
          class="form-input"
          v-model="password"
          placeholder="请输入密码"
          @keyup.enter="handleLogin"
      />
    </div>

    <button class="login-btn" @click="handleLogin">Login</button>

    <div class="login-message" v-if="message">{{ message }}</div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { loginValidation } from '@/utils/request.js'; // 导入 Axios 登录接口

const router = useRouter();
const username = ref('');
const password = ref('');
const message = ref('');
const validated = ref(0);

/**
 * 登录逻辑（适配 Axios 异步请求）
 */
const handleLogin = async () => {
  if (!username.value || !password.value) {
    message.value = '用户名和密码不能为空！';
    return;
  }

  try {
    // 调用 Axios 登录接口
    const response = await loginValidation(username.value, password.value);

    if (response.success) {
      validated.value = 1;
      message.value = '登录成功！即将进入游戏...';
      setTimeout(() => {
        router.push('/game'); // 跳转到游戏页
      }, 1000);
    } else {
      message.value = '用户名或密码错误！';
    }
  } catch (error) {
    message.value = '登录失败，请重试！';
    console.error('登录异常：', error);
  }
};
</script>

<style scoped>
/* 核心修改：移除所有 absolute 绝对定位，改用 Flex 流式布局，避免错位 */
.login-container {
  width: 380px;        /* 适度加宽，避免内容拥挤 */
  margin: 150px auto;  /* 页面水平居中，垂直留距 */
  padding: 30px 25px;  /* 增加内边距，提升美观度 */
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
  background: #fff;    /* 增加白色背景，区分页面 */
  box-sizing: border-box; /* 确保 padding 不撑大容器 */
}

.login-title {
  text-align: center;
  margin: 0 0 25px 0;  /* 调整标题间距 */
  font-size: 20px;
  color: #333;
  font-weight: 600;
}

/* 表单组：标签+输入框 水平排列 */
.form-group {
  display: flex;               /* 改用 Flex 布局 */
  align-items: center;         /* 垂直居中对齐 */
  margin-bottom: 20px;        /* 调整组间距 */
  gap: 10px;                  /* 标签和输入框的间距 */
}

.form-label {
  width: 80px;                /* 标签固定宽度，对齐更整齐 */
  font-size: 14px;
  color: #666;
  flex-shrink: 0;             /* 标签不收缩 */
}

.form-input {
  flex: 1;                    /* 输入框占满剩余宽度 */
  height: 36px;               /* 增加输入框高度，提升体验 */
  padding: 0 10px;            /* 调整内边距 */
  border: 1px solid #ccc;
  border-radius: 4px;
  outline: none;
  font-size: 14px;
  box-sizing: border-box;
}

/* 输入框聚焦样式：提升交互反馈 */
.form-input:focus {
  border-color: #42b983;
  box-shadow: 0 0 3px rgba(66, 185, 131, 0.3);
}

/* 登录按钮 */
.login-btn {
  width: 100%;                /* 按钮占满容器宽度 */
  height: 38px;               /* 统一按钮高度 */
  background: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  margin-top: 10px;           /* 与密码框拉开间距 */
  transition: background 0.3s;
}

.login-btn:hover {
  background: #359469;
}

/* 提示信息 */
.login-message {
  text-align: center;         /* 文字居中 */
  font-size: 12px;
  color: #f44336;
  margin-top: 15px;           /* 与按钮拉开间距 */
  min-height: 16px;           /* 避免内容闪烁 */
}
</style>
