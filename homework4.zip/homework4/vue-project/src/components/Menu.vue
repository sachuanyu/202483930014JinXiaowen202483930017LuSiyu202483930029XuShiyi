<template>
  <div class="menu-modal" v-if="isMenuOpen">
    <div class="menu-container">
      <h3 class="menu-title">**** {{ currentMenu.title }} ****</h3>
      <div class="menu-options">
        <div
            v-for="(item, index) in currentMenu.children"
            :key="index"
            class="menu-option"
            @click="handleOptionSelect(index)"
        >
          {{ index + 1 }}. {{ item.title }}
        </div>
      </div>
      <div class="menu-back" @click="handleBack()">
        0. Back to Upper Menu
      </div>
      <div class="menu-message" v-if="message">{{ message }}</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { gameData, readMapFromFile } from '@/utils/gameData.js';
// 导入菜单 JSON 配置
import menuConfig from '@/assets/menuConfig.json';

// 菜单状态
const isMenuOpen = ref(false);
const menuStack = ref([menuConfig]);
const message = ref('');

// 当前菜单（栈顶元素）
const currentMenu = computed(() => menuStack.value[menuStack.value.length - 1]);

/**
 * 打开菜单（对应 Java enterMenu()）
 */
const openMenu = () => {
  isMenuOpen.value = true;
  menuStack.value = [menuConfig]; // 重置菜单栈，回到根菜单
  message.value = '';
};

/**
 * 关闭菜单
 */
const closeMenu = () => {
  isMenuOpen.value = false;
  message.value = '';
};

/**
 * 处理菜单选项选择（对应 Java menuOperation 的输入处理）
 */
const handleOptionSelect = (index) => {
  const selectedItem = currentMenu.value.children[index];
  if (selectedItem.isFunction === 'No') {
    // 进入子菜单（压栈）
    menuStack.value.push(selectedItem);
    message.value = '';
  } else {
    // 执行功能（对应 Java callMethod）
    callMethod(selectedItem.isFunction);
  }
};

/**
 * 处理返回上一级（对应 Java inputNum == 0 时 return）
 */
const handleBack = () => {
  if (menuStack.value.length > 1) {
    // 子菜单返回上一级（出栈）
    menuStack.value.pop();
    message.value = '';
  } else {
    // 根菜单返回 → 关闭菜单
    closeMenu();
  }
};

/**
 * 调用菜单功能（复现 Java callMethod 反射调用）
 */
const callMethod = (functionName) => {
  switch (functionName) {
    case 'restartGame':
      restartGame();
      break;
    case 'saveGame':
      saveGame();
      break;
    case 'loadGame':
      loadGame();
      break;
    case 'quitGame':
      quitGame();
      break;
    default:
      message.value = '未知功能！';
  }
};

/**
 * 重启游戏（复现 Java restartGame()）
 */
const restartGame = () => {
  readMapFromFile();
  message.value = 'Game Restarted!!';
  setTimeout(() => closeMenu(), 1500);
};

/**
 * 退出游戏（复现 Java quitGame()）
 */
const quitGame = () => {
  if (confirm('确定要退出游戏吗？')) {
    window.close(); // 对应 Java System.exit(0)
  }
};

/**
 * 保存游戏（复现 Java saveGame()，用 localStorage 替代文件存储）
 */
const saveGame = () => {
  try {
    localStorage.setItem('GameSave', JSON.stringify({
      L: gameData.L,
      H: gameData.H,
      W: gameData.W,
      currentLevel: gameData.currentLevel,
      pX: gameData.pX,
      pY: gameData.pY,
      heroHealth: gameData.heroHealth,
      keyNum: gameData.keyNum,
      map: gameData.map
    }));
    message.value = 'Game Saved to Local Storage';
  } catch (error) {
    message.value = 'Save Failed!';
    console.error(error);
  }
};

/**
 * 加载游戏（复现 Java loadGame()，从 localStorage 读取）
 */
const loadGame = () => {
  try {
    const savedData = localStorage.getItem('GameSave');
    if (!savedData) {
      message.value = 'No Saved Game Found!';
      return;
    }
    const parsedData = JSON.parse(savedData);
    // 复制字段到 gameData（对应 Java 的 copyFields）
    Object.entries(parsedData).forEach(([key, value]) => {
      if (gameData.hasOwnProperty(key)) {
        gameData[key] = value;
      }
    });
    message.value = 'Game Loaded from Local Storage';
    setTimeout(() => closeMenu(), 1500);
  } catch (error) {
    message.value = 'Load Failed!';
    console.error(error);
  }
};

// 暴露菜单控制方法（供 Game.vue 调用）
defineExpose({
  openMenu,
  closeMenu
});
</script>

<style scoped>
.menu-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 100;
}

.menu-container {
  background: white;
  padding: 30px;
  border-radius: 8px;
  width: 300px;
  text-align: center;
}

.menu-title {
  margin: 0 0 20px 0;
  color: #333;
  font-size: 18px;
}

.menu-options {
  margin-bottom: 20px;
}

.menu-option {
  padding: 8px 0;
  cursor: pointer;
  border-bottom: 1px solid #eee;
  font-size: 14px;
  color: #666;
}

.menu-option:hover {
  background: #f5f5f5;
  color: #42b983;
}

.menu-back {
  padding: 8px 0;
  cursor: pointer;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
  color: #666;
  margin-bottom: 15px;
}

.menu-back:hover {
  background: #f5f5f5;
  color: #f44336;
}

.menu-message {
  font-size: 12px;
  color: #42b983;
}
</style>