import axios from 'axios';

// 创建axios实例，指向后端8081端口
const service = axios.create({
    baseURL: 'http://localhost:8081', // 后端基础地址
    timeout: 5000, // 请求超时时间
    headers: {
        'Content-Type': 'application/json;charset=utf-8' // 明确JSON格式，适配后端@RequestBody
    }
});

/**
 * 登录验证（POST + JSON 参数 + /api/login路径，适配后端）
 * @param {string} username 用户名
 * @param {string} password 密码
 * @returns {Promise<Object>} 登录结果
 */
export const loginValidation = async (username, password) => {
    try {
        // 核心修复：POST请求 + /api/login路径 + JSON参数
        const res = await service.post('/api/login', {
            username: username,
            password: password
        });
        // 直接返回后端数据（包含success/message字段）
        return res.data;
    } catch (error) {
        console.error('登录请求失败：', error);
        // 统一返回格式，避免前端报错
        return {
            success: false,
            message: '登录失败（请检查后端8081是否启动/跨域配置）'
        };
    }
};

/**
 * 适配gameControl.js的fetchPlayers（保留，避免其他报错）
 */
export const fetchPlayers = async () => {
    try {
        const res = await service.get('/api/players'); // 若后端有players接口，需加/api前缀
        return res.data;
    } catch (error) {
        console.error('获取玩家列表失败：', error);
        return { code: 500, data: [], message: '接口请求失败' };
    }
};

/**
 * 适配gameControl.js的fetchWorlds（保留，避免其他报错）
 */
export const fetchWorlds = async () => {
    try {
        const res = await service.get('/api/worlds'); // 若后端有worlds接口，需加/api前缀
        return res.data;
    } catch (error) {
        console.error('获取世界列表失败：', error);
        return { code: 500, data: [], message: '接口请求失败' };
    }
};

// 兼容旧命名（可选，防止其他代码调用报错）
export const getPlayers = fetchPlayers;
export const getWorlds = fetchWorlds;