import { gameData } from './gameData.js';
import { fetchWorlds, fetchPlayers } from './request.js'; // 导入 Axios 接口

/**
 * 移动英雄（复现 Java moveHero 方法）
 */
export function moveHero(tX, tY) {
    gameData.map[gameData.currentLevel][gameData.pX][gameData.pY] = 1;
    gameData.map[gameData.currentLevel][tX][tY] = 6;
    gameData.pX = tX;
    gameData.pY = tY;
}

/**
 * 处理移动输入（复现 Java handleInput 方法）
 */
export function handleInput(key) {
    let tX = gameData.pX;
    let tY = gameData.pY;
    const result = {
        message: '',
        isGameOver: false,
        isWin: false
    };

    // 计算目标坐标
    switch (key) {
        case 'a': tY -= 1; break;
        case 's': tX += 1; break;
        case 'd': tY += 1; break;
        case 'w': tX -= 1; break;
        default:
            result.message = '无效输入！仅支持 a/s/d/w 移动';
            return result;
    }

    // 边界检测
    if (tX < 0 || tX >= gameData.H || tY < 0 || tY >= gameData.W) {
        result.message = '碰到边界啦！无法移动';
        return result;
    }

    const targetValue = gameData.map[gameData.currentLevel][tX][tY];

    // 地形交互逻辑
    switch (true) {
        case targetValue === 2: // 钥匙
            gameData.keyNum++;
            moveHero(tX, tY);
            result.message = `拾取钥匙！当前钥匙数：${gameData.keyNum}`;
            break;
        case targetValue === 3: // 门
            if (gameData.keyNum > 0) {
                gameData.keyNum--;
                moveHero(tX, tY);
                result.message = `使用钥匙开门！剩余钥匙数：${gameData.keyNum}`;
            } else {
                result.message = '没有钥匙，无法开门！';
            }
            break;
        case targetValue === 4: // 楼梯
            gameData.map[gameData.currentLevel][gameData.pX][gameData.pY] = 1;
            gameData.currentLevel++;
            let found = false;
            for (let i = 0; i < gameData.H && !found; i++) {
                for (let j = 0; j < gameData.W && !found; j++) {
                    if (gameData.map[gameData.currentLevel][i][j] === 6) {
                        gameData.pX = i;
                        gameData.pY = j;
                        found = true;
                    }
                }
            }
            result.message = `进入第 ${gameData.currentLevel + 1} 层！`;
            break;
        case targetValue === 5: // 出口
            result.message = 'You Win!!';
            result.isWin = true;
            result.isGameOver = true;
            break;
        case targetValue > 10: // 增益道具
            gameData.heroHealth += targetValue;
            moveHero(tX, tY);
            result.message = `获得增益！生命值 +${targetValue}，当前：${gameData.heroHealth}`;
            break;
        case targetValue === 1: // 地板
            moveHero(tX, tY);
            result.message = '移动成功';
            break;
        case targetValue < 0: // 怪物
            const monsterPower = -targetValue;
            if (gameData.heroHealth + targetValue <= 0) {
                result.message = `怪物攻击力 ${monsterPower}！你输了！`;
                result.isGameOver = true;
            } else {
                gameData.heroHealth += targetValue;
                moveHero(tX, tY);
                result.message = `击败怪物！生命值 -${monsterPower}，当前：${gameData.heroHealth}`;
            }
            break;
        default:
            result.message = '无法移动到这里！';
            break;
    }

    return result;
}

/**
 * 处理特殊按键（v/b 调用接口）
 */
export function handleSpecialKey(key) {
    switch (key) {
        case 'v':
            return fetchWorlds(2).then(res =>
                `调用 fetchWorlds(2) 成功：${JSON.stringify(res)}`
            ).catch(err => `调用失败：${err.message}`);
        case 'b':
            return fetchPlayers(1).then(res =>
                `调用 fetchPlayers(1) 成功：${JSON.stringify(res)}`
            ).catch(err => `调用失败：${err.message}`);
        default:
            return Promise.resolve('无对应特殊功能');
    }
}