/**
 * 游戏数据管理模块（使用 map.json 存储地图数据）
 */
// gameData 是变量，直接用 export 定义（无需在末尾重复导出）
export const gameData = {
    L: 0,          // 地图层数
    H: 0,          // 每层高度（行数）
    W: 0,          // 每层宽度（列数）
    currentLevel: 0, // 当前楼层
    pX: 3,         // 英雄X坐标（行）- 固定初始值 3
    pY: 3,         // 英雄Y坐标（列）- 固定初始值 3
    heroHealth: 105, // 英雄生命值
    keyNum: 0,     // 钥匙数量
    map: []        // 3D地图数组 [层数][行][列]
};

// 导入地图 JSON 数据
import mapJson from '@/assets/map.json';

/**
 * 读取地图数据（从 map.json 加载）
 */
// 去掉方法前的 export，改为末尾统一导出
function readMapFromFile() {
    // 初始化游戏数据
    gameData.currentLevel = 0;
    gameData.heroHealth = 105;
    gameData.keyNum = 0;
    gameData.pX = 3;
    gameData.pY = 3;

    // 从 JSON 读取地图维度
    gameData.L = mapJson.L;
    gameData.H = mapJson.H;
    gameData.W = mapJson.W;

    // 初始化 3D 地图数组
    gameData.map = new Array(gameData.L);
    for (let i = 0; i < gameData.L; i++) {
        gameData.map[i] = new Array(gameData.H);
        for (let j = 0; j < gameData.H; j++) {
            gameData.map[i][j] = new Array(gameData.W).fill(0);
        }
    }

    // 填充地图数据
    let index = 0;
    for (let i = 0; i < gameData.L; i++) {
        for (let j = 0; j < gameData.H; j++) {
            for (let k = 0; k < gameData.W; k++) {
                gameData.map[i][j][k] = mapJson.data[index++];
            }
        }
    }

    console.log("地图读取成功（从 map.json 加载）！");
    return true;
}

/**
 * 打印当前楼层地图（完全同步 Java 逻辑）
 */
// 去掉方法前的 export，改为末尾统一导出
function printMap() {
    const C = ['W', '_', 'K', 'D', 'S', 'E', 'H'];
    let mapStr = "";

    for (let j = 0; j < gameData.H; j++) {
        for (let k = 0; k < gameData.W; k++) {
            const tileValue = gameData.map[gameData.currentLevel][j][k];
            if (tileValue < 0) {
                mapStr += "M ";
            } else if (tileValue > 10) {
                mapStr += "P ";
            } else {
                mapStr += `${C[tileValue]} `;
            }
        }
        mapStr += "\n\n";
    }

    mapStr += `Health:${gameData.heroHealth}  KeyNum:${gameData.keyNum}  Menu:press 0\n`;
    return mapStr;
}

/**
 * 复制字段（同步 Java 逻辑）
 */
function copyFields(source) {
    try {
        const fieldNames = Object.keys(gameData);
        fieldNames.forEach(fieldName => {
            if (source.hasOwnProperty(fieldName)) {
                gameData[fieldName] = source[fieldName];
            }
        });
        console.log("字段复制成功！");
    } catch (error) {
        console.error("字段复制失败：", error.message);
    }
}

// 末尾统一导出所有成员（仅此处导出，无重复）
export {
    readMapFromFile,
    printMap,
    copyFields
};