<template>
  <div id="app">
    <!-- 路由出口：自动根据路由切换登录页/游戏页 -->
    <router-view />
  </div>
</template>

<script setup>
import { onMounted } from 'vue';
import { useRouter } from 'vue-router';
// 统一导入 gameData 和方法（避免重复导入）
import { gameData, readMapFromFile, printMap } from '@/utils/gameData.js';

const router = useRouter();

/**
 * 复现 Java MagicTowerMain 的 main 方法逻辑：
 * 1. 优先进入登录页（对应 Java new Login()）
 * 2. 登录成功后，自动加载地图（对应 Java gameData.readMapFromFile）
 * 3. 初始化游戏数据，启动游戏
 */
onMounted(() => {
  // 监听路由变化（登录成功跳转到游戏页时触发）
  const routeWatcher = router.afterEach((to) => {
    if (to.path === '/game') {
      // 1. 加载地图（无需传参，readMapFromFile 内部已导入 map.json）
      readMapFromFile();
      console.log("地图加载完成（对应 Java readMapFromFile）");

      // 2. 打印地图（使用单独导入的 printMap 方法，而非 gameData 的属性）
      const mapStr = printMap();
      console.log("当前地图：\n", mapStr);

      // 3. 游戏启动（Game.vue 会自动监听键盘事件，实现游戏交互）
      console.log("游戏启动成功（对应 Java gameControl.gameStart()）");

      // 移除监听器（仅执行一次地图加载）
      routeWatcher();
    }
  });
});
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>