// vite.config.js
import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "file:///C:/Users/teran/Desktop/vue-project/node_modules/vite/dist/node/index.js";
import vue from "file:///C:/Users/teran/Desktop/vue-project/node_modules/@vitejs/plugin-vue/dist/index.mjs";
import vueDevTools from "file:///C:/Users/teran/Desktop/vue-project/node_modules/vite-plugin-vue-devtools/dist/vite.mjs";
var __vite_injected_original_import_meta_url = "file:///C:/Users/teran/Desktop/vue-project/vite.config.js";
var vite_config_default = defineConfig({
  plugins: [
    vue(),
    vueDevTools()
  ],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", __vite_injected_original_import_meta_url))
    }
  },
  // 新增：跨域代理配置（解决前端5173请求后端8081的CORS问题）
  server: {
    proxy: {
      // 匹配所有以 /api 开头的请求，转发到后端8081端口
      "/api": {
        target: "http://localhost:8081",
        // 后端接口的基础地址
        changeOrigin: true,
        // 开启跨域代理（关键：模拟后端的请求头）
        rewrite: (path) => path.replace(/^\/api/, "")
        // 去掉请求路径中的/api前缀
      }
    }
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJDOlxcXFxVc2Vyc1xcXFx0ZXJhblxcXFxEZXNrdG9wXFxcXHZ1ZS1wcm9qZWN0XCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ZpbGVuYW1lID0gXCJDOlxcXFxVc2Vyc1xcXFx0ZXJhblxcXFxEZXNrdG9wXFxcXHZ1ZS1wcm9qZWN0XFxcXHZpdGUuY29uZmlnLmpzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9DOi9Vc2Vycy90ZXJhbi9EZXNrdG9wL3Z1ZS1wcm9qZWN0L3ZpdGUuY29uZmlnLmpzXCI7aW1wb3J0IHsgZmlsZVVSTFRvUGF0aCwgVVJMIH0gZnJvbSAnbm9kZTp1cmwnXG5pbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlJ1xuaW1wb3J0IHZ1ZSBmcm9tICdAdml0ZWpzL3BsdWdpbi12dWUnXG5pbXBvcnQgdnVlRGV2VG9vbHMgZnJvbSAndml0ZS1wbHVnaW4tdnVlLWRldnRvb2xzJ1xuXG4vLyBodHRwczovL3ZpdGUuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtcbiAgICB2dWUoKSxcbiAgICB2dWVEZXZUb29scygpLFxuICBdLFxuICByZXNvbHZlOiB7XG4gICAgYWxpYXM6IHtcbiAgICAgICdAJzogZmlsZVVSTFRvUGF0aChuZXcgVVJMKCcuL3NyYycsIGltcG9ydC5tZXRhLnVybCkpXG4gICAgfSxcbiAgfSxcbiAgLy8gXHU2NUIwXHU1ODlFXHVGRjFBXHU4REU4XHU1N0RGXHU0RUUzXHU3NDA2XHU5MTREXHU3RjZFXHVGRjA4XHU4OUUzXHU1MUIzXHU1MjREXHU3QUVGNTE3M1x1OEJGN1x1NkM0Mlx1NTQwRVx1N0FFRjgwODFcdTc2ODRDT1JTXHU5NUVFXHU5ODk4XHVGRjA5XG4gIHNlcnZlcjoge1xuICAgIHByb3h5OiB7XG4gICAgICAvLyBcdTUzMzlcdTkxNERcdTYyNDBcdTY3MDlcdTRFRTUgL2FwaSBcdTVGMDBcdTU5MzRcdTc2ODRcdThCRjdcdTZDNDJcdUZGMENcdThGNkNcdTUzRDFcdTUyMzBcdTU0MEVcdTdBRUY4MDgxXHU3QUVGXHU1M0UzXG4gICAgICAnL2FwaSc6IHtcbiAgICAgICAgdGFyZ2V0OiAnaHR0cDovL2xvY2FsaG9zdDo4MDgxJywgLy8gXHU1NDBFXHU3QUVGXHU2M0E1XHU1M0UzXHU3Njg0XHU1N0ZBXHU3ODQwXHU1NzMwXHU1NzQwXG4gICAgICAgIGNoYW5nZU9yaWdpbjogdHJ1ZSwgLy8gXHU1RjAwXHU1NDJGXHU4REU4XHU1N0RGXHU0RUUzXHU3NDA2XHVGRjA4XHU1MTczXHU5NTJFXHVGRjFBXHU2QTIxXHU2MkRGXHU1NDBFXHU3QUVGXHU3Njg0XHU4QkY3XHU2QzQyXHU1OTM0XHVGRjA5XG4gICAgICAgIHJld3JpdGU6IChwYXRoKSA9PiBwYXRoLnJlcGxhY2UoL15cXC9hcGkvLCAnJykgLy8gXHU1M0JCXHU2Mzg5XHU4QkY3XHU2QzQyXHU4REVGXHU1Rjg0XHU0RTJEXHU3Njg0L2FwaVx1NTI0RFx1N0YwMFxuICAgICAgfVxuICAgIH1cbiAgfVxufSkiXSwKICAibWFwcGluZ3MiOiAiO0FBQWtTLFNBQVMsZUFBZSxXQUFXO0FBQ3JVLFNBQVMsb0JBQW9CO0FBQzdCLE9BQU8sU0FBUztBQUNoQixPQUFPLGlCQUFpQjtBQUg2SixJQUFNLDJDQUEyQztBQU10TyxJQUFPLHNCQUFRLGFBQWE7QUFBQSxFQUMxQixTQUFTO0FBQUEsSUFDUCxJQUFJO0FBQUEsSUFDSixZQUFZO0FBQUEsRUFDZDtBQUFBLEVBQ0EsU0FBUztBQUFBLElBQ1AsT0FBTztBQUFBLE1BQ0wsS0FBSyxjQUFjLElBQUksSUFBSSxTQUFTLHdDQUFlLENBQUM7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBRUEsUUFBUTtBQUFBLElBQ04sT0FBTztBQUFBO0FBQUEsTUFFTCxRQUFRO0FBQUEsUUFDTixRQUFRO0FBQUE7QUFBQSxRQUNSLGNBQWM7QUFBQTtBQUFBLFFBQ2QsU0FBUyxDQUFDLFNBQVMsS0FBSyxRQUFRLFVBQVUsRUFBRTtBQUFBO0FBQUEsTUFDOUM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
