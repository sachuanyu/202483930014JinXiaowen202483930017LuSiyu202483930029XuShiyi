import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueDevTools from 'vite-plugin-vue-devtools'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    vue(),
    vueDevTools(),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
  // 新增：跨域代理配置（解决前端5173请求后端8081的CORS问题）
  server: {
    proxy: {
      // 匹配所有以 /api 开头的请求，转发到后端8081端口
      '/api': {
        target: 'http://localhost:8081', // 后端接口的基础地址
        changeOrigin: true, // 开启跨域代理（关键：模拟后端的请求头）
        rewrite: (path) => path.replace(/^\/api/, '') // 去掉请求路径中的/api前缀
      }
    }
  }
})